
import React, { useState } from 'react';
import Header from './components/Header.tsx';
import HomeScreen from './components/VideoPlayer.tsx';
import ServiceForm from './components/InputForm.tsx';
import ConfirmationScreen from './components/Loader.tsx';
import ProviderHomeScreen from './components/ProviderHomeScreen.tsx';
import ProviderForm from './components/ProviderForm.tsx';


export type ServiceType = 'transport' | 'craftsmen' | 'appointments' | 'home_services';
export type View = 'home' | 'form' | 'confirmation' | 'provider_home' | 'provider_form';

const App: React.FC = () => {
    const [view, setView] = useState<View>('home');
    const [currentService, setCurrentService] = useState<{ type: ServiceType; title: string } | null>(null);
    const [confirmationDetails, setConfirmationDetails] = useState({ title: '', message: '' });

    const handleSelectService = (serviceType: ServiceType, title: string) => {
        setCurrentService({ type: serviceType, title });
        setView('form');
    };

    const handleBackToHome = () => {
        setView('home');
        setCurrentService(null);
    };

    const handleSubmit = (formData: { [key: string]: string }) => {
        console.log('Customer Form Submitted:', {
            service: currentService,
            data: formData,
        });
        setConfirmationDetails({
            title: 'تم استلام طلبك بنجاح!',
            message: `لقد تم إرسال طلبك الخاص بخدمة <span class="font-bold text-purple-300">"${currentService?.title}"</span>. سيقوم فريقنا بمراجعة الطلب والتواصل معك في أقرب وقت ممكن.`
        });
        setView('confirmation');
    };

    const handleNavigateToProvider = () => {
        setView('provider_home');
    };
    
    const handleSelectProviderService = (serviceType: ServiceType, title: string) => {
        setCurrentService({ type: serviceType, title });
        setView('provider_form');
    };

    const handleProviderSubmit = (formData: { [key: string]: string }) => {
        console.log('Provider Form Submitted:', {
            service: currentService,
            data: formData,
        });
        setConfirmationDetails({
            title: 'تم استلام طلب التسجيل!',
            message: `شكراً لانضمامك إلينا كشريك في خدمة <span class="font-bold text-purple-300">"${currentService?.title}"</span>. سنقوم بمراجعة بياناتك والتواصل معك قريباً.`
        });
        setView('confirmation');
    };

    const renderContent = () => {
        switch (view) {
            case 'form':
                if (!currentService) return <HomeScreen onSelectService={handleSelectService} onNavigateToProvider={handleNavigateToProvider} />;
                return (
                    <ServiceForm
                        serviceType={currentService.type}
                        title={currentService.title}
                        onBack={handleBackToHome}
                        onSubmit={handleSubmit}
                    />
                );
            case 'provider_home':
                return <ProviderHomeScreen onSelectService={handleSelectProviderService} onBack={handleBackToHome} />;
            case 'provider_form':
                 if (!currentService) return <ProviderHomeScreen onSelectService={handleSelectProviderService} onBack={handleBackToHome} />;
                 return (
                    <ProviderForm
                        serviceType={currentService.type}
                        title={`تسجيل كمزود خدمة: ${currentService.title}`}
                        onBack={() => setView('provider_home')}
                        onSubmit={handleProviderSubmit}
                    />
                );
            case 'confirmation':
                return <ConfirmationScreen onBackToHome={handleBackToHome} title={confirmationDetails.title} message={<p dangerouslySetInnerHTML={{ __html: confirmationDetails.message }} />} />;
            case 'home':
            default:
                return <HomeScreen onSelectService={handleSelectService} onNavigateToProvider={handleNavigateToProvider} />;
        }
    };

    return (
        <div className="bg-gray-900 min-h-screen text-white flex flex-col antialiased">
            <Header />
            <main className="flex-grow container mx-auto p-4 lg:p-8 flex items-center justify-center">
                <div className="w-full max-w-4xl">
                   {renderContent()}
                </div>
            </main>
        </div>
    );
};

export default App;
