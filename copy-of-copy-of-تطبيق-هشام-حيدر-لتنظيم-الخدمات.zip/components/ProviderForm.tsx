
import React, { useState } from 'react';
import { ServiceType } from '../App.tsx';
import { ArrowRightIcon } from '../types.ts';

interface ProviderFormProps {
    serviceType: ServiceType;
    title: string;
    onBack: () => void;
    onSubmit: (formData: { [key: string]: string }) => void;
}

// Reusable Form Components
const FormInput: React.FC<{label: string, name: string, type?: string, placeholder?: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, required?: boolean}> = 
    ({label, name, type = 'text', placeholder = '', value, onChange, required = true}) => (
    <div>
        <label htmlFor={name} className="block mb-2 text-sm font-medium text-gray-300">{label}</label>
        <input type={type} id={name} name={name} value={value} onChange={onChange} className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5" placeholder={placeholder} required={required} />
    </div>
);

const FormSelect: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, children: React.ReactNode}> = 
    ({label, name, value, onChange, children}) => (
    <div>
        <label htmlFor={name} className="block mb-2 text-sm font-medium text-gray-300">{label}</label>
        <select id={name} name={name} value={value} onChange={onChange} className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5" required>
            {children}
        </select>
    </div>
);

const FormTextarea: React.FC<{label: string, name: string, placeholder?: string, value: string, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void}> = 
    ({label, name, placeholder = '', value, onChange}) => (
    <div>
        <label htmlFor={name} className="block mb-2 text-sm font-medium text-gray-300">{label}</label>
        <textarea id={name} name={name} rows={4} value={value} onChange={onChange} className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 resize-none" placeholder={placeholder}></textarea>
    </div>
);

const FormCheckbox: React.FC<{label: string, name: string, checked: boolean, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void}> = 
    ({label, name, checked, onChange}) => (
    <div className="flex items-center">
        <input id={name} name={name} type="checkbox" checked={checked} onChange={onChange} className="w-5 h-5 text-purple-600 bg-gray-700 border-gray-600 rounded focus:ring-purple-500" required/>
        <label htmlFor={name} className="ms-3 text-sm font-medium text-gray-300">{label}</label>
    </div>
);


const ProviderForm: React.FC<ProviderFormProps> = ({ serviceType, title, onBack, onSubmit }) => {
    const [formData, setFormData] = useState<{ [key: string]: any }>({
        hasValidLicense: true,
        hasValidId: true,
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        const isCheckbox = type === 'checkbox';
        setFormData({
            ...formData,
            [name]: isCheckbox ? (e.target as HTMLInputElement).checked : value,
        });
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    const renderProviderFormFields = () => {
        const commonFields = (
            <>
                <FormInput label="الاسم بالكامل" name="fullName" placeholder="اسمك كما في الهوية" value={formData.fullName || ''} onChange={handleChange} />
                <FormInput label="رقم الهاتف" name="phone" type="tel" placeholder="01xxxxxxxxx" value={formData.phone || ''} onChange={handleChange} />
            </>
        );

        switch (serviceType) {
            case 'transport':
                return (
                    <>
                        {commonFields}
                        <FormSelect label="نوع المركبة" name="vehicleType" value={formData.vehicleType || ''} onChange={handleChange}>
                            <option value="">اختر نوع المركبة...</option>
                            <option value="سيارة ملاكي">سيارة ملاكي</option>
                            <option value="ميكروباص">ميكروباص</option>
                            <option value="باص">باص</option>
                            <option value="شاحنة ربع نقل">شاحنة ربع نقل</option>
                            <option value="شاحنة نصف نقل">شاحنة نصف نقل</option>
                            <option value="شاحنة نقل">شاحنة نقل (كبيرة)</option>
                        </FormSelect>
                        <FormInput label="موديل المركبة" name="vehicleModel" placeholder="مثال: شيفروليه لانوس 2019" value={formData.vehicleModel || ''} onChange={handleChange} />
                        <FormInput label="رقم لوحة المركبة" name="licensePlate" placeholder="أرقام وحروف اللوحة" value={formData.licensePlate || ''} onChange={handleChange} />
                        <FormInput label="المرور التابع له" name="trafficDepartment" placeholder="مثال: مرور حلوان" value={formData.trafficDepartment || ''} onChange={handleChange} />
                        <div className="space-y-3 pt-4 border-t border-gray-700">
                           <FormCheckbox label="أقر بأنني أحمل رخصة قيادة سارية." name="hasValidLicense" checked={formData.hasValidLicense} onChange={handleChange} />
                           <FormCheckbox label="أقر بأنني سأقدم إثبات هوية ساري عند الطلب." name="hasValidId" checked={formData.hasValidId} onChange={handleChange} />
                        </div>
                    </>
                );
            case 'craftsmen':
                return (
                    <>
                        {commonFields}
                        <FormSelect label="حدد الحرفة" name="craft" value={formData.craft || ''} onChange={handleChange}>
                            <option value="">اختر الحرفة...</option>
                            <option value="سباك">سباك</option>
                            <option value="كهربائي">كهربائي</option>
                            <option value="نجار">نجار</option>
                            <option value="فني تكييف">فني تكييف وتبريد</option>
                            <option value="نقاش">نقاش (دهانات)</option>
                            <option value="أخرى">أخرى</option>
                        </FormSelect>
                        <FormTextarea label="نبذة عن خبرتك والخدمات التي تقدمها" name="experience" placeholder="مثال: لدي خبرة 10 سنوات في جميع أعمال السباكة، تركيب وصيانة..." value={formData.experience || ''} onChange={handleChange} />
                        <FormInput label="مناطق العمل التي تغطيها" name="workArea" placeholder="مثال: القاهرة الكبرى، حلوان والمعادي" value={formData.workArea || ''} onChange={handleChange} />
                    </>
                );
            case 'appointments':
                return (
                    <>
                        {commonFields}
                        <FormSelect label="حدد نوع الخدمة" name="appointmentType" value={formData.appointmentType || ''} onChange={handleChange}>
                            <option value="">اختر نوع الخدمة التي تقدمها...</option>
                            <option value="محاماة">محاماة واستشارات قانونية</option>
                            <option value="كوافير">كوافير / صالون تجميل</option>
                            <option value="عيادة أسنان">عيادة أسنان</option>
                            <option value="عيادة طبية">عيادة طبية (تخصص آخر)</option>
                            <option value="دروس خصوصية">سنتر ودروس خصوصية</option>
                            <option value="أخرى">أخرى</option>
                        </FormSelect>
                         <FormInput label="اسم العيادة / المكتب / المركز" name="officeName" placeholder="اسم المكان الذي تقدم فيه الخدمة" value={formData.officeName || ''} onChange={handleChange} />
                         <FormInput label="عنوان مقر العمل" name="officeAddress" placeholder="المدينة، الحي، الشارع، رقم المبنى" value={formData.officeAddress || ''} onChange={handleChange} />
                    </>
                );
            case 'home_services':
                 return (
                    <>
                        {commonFields}
                        <FormSelect label="حدد نوع الخدمة المنزلية" name="homeServiceType" value={formData.homeServiceType || ''} onChange={handleChange}>
                            <option value="">اختر الخدمة...</option>
                            <option value="توصيل للمنزل">خدمات توصيل للمنزل (دليفري)</option>
                            <option value="تنظيف منازل">خدمات تنظيف منازل</option>
                            <option value="مكافحة حشرات">خدمات مكافحة حشرات</option>
                            <option value="نقل أثاث">خدمات نقل أثاث</option>
                            <option value="أخرى">أخرى</option>
                        </FormSelect>
                        <FormTextarea label="وصف تفصيلي للخدمة التي تقدمها" name="serviceDescription" placeholder="مثال: أقوم بتوصيل كافة الطلبات من المتاجر والصيدليات..." value={formData.serviceDescription || ''} onChange={handleChange} />
                         <FormInput label="مناطق العمل التي تغطيها" name="workArea" placeholder="مثال: مدينة نصر ومصر الجديدة" value={formData.workArea || ''} onChange={handleChange} />
                    </>
                );
            default:
                return <p>حدث خطأ، يرجى العودة للخلف.</p>;
        }
    };

    return (
        <div className="bg-gray-800 rounded-2xl p-6 md:p-8 border border-gray-700 shadow-2xl w-full animate-fade-in">
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl md:text-2xl font-bold text-white">{title}</h2>
                <button onClick={onBack} className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-gray-700">
                    <ArrowRightIcon className="w-6 h-6 rtl-flip" />
                    <span className="sr-only">عودة</span>
                </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                {renderProviderFormFields()}
                <button type="submit" className="w-full flex items-center justify-center gap-3 bg-teal-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-teal-700 active:bg-teal-800 transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-teal-500">
                    إرسال طلب التسجيل
                </button>
            </form>
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default ProviderForm;
