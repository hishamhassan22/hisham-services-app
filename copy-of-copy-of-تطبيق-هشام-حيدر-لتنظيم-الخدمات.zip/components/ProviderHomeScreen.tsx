
import React from 'react';
import ServiceCard from './icons/services/geminiService.ts';
import { ServiceType } from '../App.tsx';
import { CarIcon } from './icons/FilmIcon.tsx';
import { WrenchIcon } from './icons/WandIcon.tsx';
import { CalendarIcon } from './icons/ImageViewer.tsx';
import { HomeIcon } from './icons/SparklesIcon.tsx';
import { ArrowRightIcon } from '../types.ts';

interface ProviderHomeScreenProps {
    onSelectService: (serviceType: ServiceType, title: string) => void;
    onBack: () => void;
}

const providerServices = [
    {
        type: 'transport' as ServiceType,
        title: 'تقديم خدمات النقل والمواصلات',
        description: 'سجل مركبتك سواء كانت سيارة، باص، أو شاحنة نقل.',
        icon: <CarIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    },
    {
        type: 'craftsmen' as ServiceType,
        title: 'تقديم خدمات كحرفي أو صنايعي',
        description: 'إذا كنت سباك، كهربائي، أو أي حرفة أخرى، انضم إلينا.',
        icon: <WrenchIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    },
    {
        type: 'appointments' as ServiceType,
        title: 'تقديم خدمات تتطلب حجز مواعيد',
        description: 'للمحامين، الأطباء، الكوافيرات، وغيرهم من مقدمي الخدمات.',
        icon: <CalendarIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    },
    {
        type: 'home_services' as ServiceType,
        title: 'تقديم خدمات منزلية متنوعة',
        description: 'سجل لتقديم خدمات التوصيل، التنظيف، وغيرها.',
        icon: <HomeIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    }
];

const ProviderHomeScreen: React.FC<ProviderHomeScreenProps> = ({ onSelectService, onBack }) => {
    return (
        <div className="animate-fade-in w-full">
            <div className="flex items-center justify-between mb-10">
                 <h2 className="text-4xl font-extrabold text-white">بوابة الشركاء</h2>
                 <button onClick={onBack} className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-gray-700">
                    <ArrowRightIcon className="w-6 h-6 rtl-flip" />
                    <span className="sr-only">عودة</span>
                </button>
            </div>
           
            <p className="text-gray-400 mt-2 mb-8 text-lg text-center">اختر فئة الخدمة التي ترغب في تقديمها للانضمام إلى شبكتنا.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {providerServices.map((service) => (
                    <ServiceCard
                        key={service.type}
                        title={service.title}
                        description={service.description}
                        icon={service.icon}
                        onClick={() => onSelectService(service.type, service.title)}
                    />
                ))}
            </div>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default ProviderHomeScreen;
