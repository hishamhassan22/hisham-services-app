
import React from 'react';
import ServiceCard from './icons/services/geminiService.ts';
import { ServiceType } from '../App.tsx';
import { CarIcon } from './icons/FilmIcon.tsx';
import { WrenchIcon } from './icons/WandIcon.tsx';
import { CalendarIcon } from './icons/ImageViewer.tsx';
import { HomeIcon } from './icons/SparklesIcon.tsx';
import { BriefcaseIcon } from './icons/BriefcaseIcon.tsx';

interface HomeScreenProps {
    onSelectService: (serviceType: ServiceType, title: string) => void;
    onNavigateToProvider: () => void;
}

const services = [
    {
        type: 'transport' as ServiceType,
        title: 'طلب رحلة أو مواصلة',
        description: 'اطلب سيارة لتوصيلة داخلية أو للسفر بين المدن.',
        icon: <CarIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    },
    {
        type: 'craftsmen' as ServiceType,
        title: 'طلب خدمة صنايعي أو حرفي',
        description: 'ابحث عن فنيين وحرفيين معتمدين لجميع احتياجاتك.',
        icon: <WrenchIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    },
    {
        type: 'appointments' as ServiceType,
        title: 'طلب حجز مواعيد',
        description: 'احجز مواعيدك مع محامين، أطباء، كوافير وغيرهم بسهولة.',
        icon: <CalendarIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    },
    {
        type: 'home_services' as ServiceType,
        title: 'خدمات منزلية متنوعة',
        description: 'اطلب خدمات توصيل للمنازل، تنظيف، أو غيرها من الخدمات.',
        icon: <HomeIcon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300" />
    }
];

const HomeScreen: React.FC<HomeScreenProps> = ({ onSelectService, onNavigateToProvider }) => {
    return (
        <div className="animate-fade-in w-full">
            <div className="text-center mb-10">
                <h2 className="text-4xl font-extrabold text-white">مرحباً بك</h2>
                <p className="text-gray-400 mt-2 text-lg">اختر الخدمة التي تحتاجها للبدء</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {services.map((service) => (
                    <ServiceCard
                        key={service.type}
                        title={service.title}
                        description={service.description}
                        icon={service.icon}
                        onClick={() => onSelectService(service.type, service.title)}
                    />
                ))}
            </div>
             <div className="mt-12 border-t-2 border-gray-700/50 pt-8 text-center">
                <button 
                    onClick={onNavigateToProvider}
                    className="group inline-flex items-center gap-4 bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 font-bold py-4 px-8 rounded-xl border-2 border-teal-500/30 hover:border-teal-500/60 transition-all duration-300 transform hover:-translate-y-1"
                >
                    <BriefcaseIcon className="w-7 h-7" />
                    <span>هل أنت مزود خدمة؟ انضم إلينا الآن</span>
                </button>
            </div>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default HomeScreen;
