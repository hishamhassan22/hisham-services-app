import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/70 backdrop-blur-sm border-b border-gray-700/50 sticky top-0 z-30">
      <div className="container mx-auto px-4 lg:px-8 py-4 flex justify-center items-center">
        <h1 className="text-2xl lg:text-3xl font-bold bg-gradient-to-r from-purple-400 to-indigo-400 text-transparent bg-clip-text">
          تطبيق هشام حيدر لتنظيم الخدمات
        </h1>
      </div>
    </header>
  );
};

export default Header;
