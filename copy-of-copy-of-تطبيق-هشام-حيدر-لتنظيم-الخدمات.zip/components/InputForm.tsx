import React, { useState } from 'react';
import { ServiceType } from '../App.tsx';
import { ArrowRightIcon } from '../types.ts';
import { LocationMarkerIcon } from './icons/LocationMarkerIcon.tsx';

interface ServiceFormProps {
    serviceType: ServiceType;
    title: string;
    onBack: () => void;
    onSubmit: (formData: { [key: string]: string }) => void;
}

const FormInput: React.FC<{label: string, name: string, type?: string, placeholder?: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void}> = 
    ({label, name, type = 'text', placeholder = '', value, onChange}) => (
    <div>
        <label htmlFor={name} className="block mb-2 text-sm font-medium text-gray-300">{label}</label>
        <input type={type} id={name} name={name} value={value} onChange={onChange} className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5" placeholder={placeholder} required />
    </div>
);

const FormSelect: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, children: React.ReactNode}> = 
    ({label, name, value, onChange, children}) => (
    <div>
        <label htmlFor={name} className="block mb-2 text-sm font-medium text-gray-300">{label}</label>
        <select id={name} name={name} value={value} onChange={onChange} className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5" required>
            {children}
        </select>
    </div>
);

const FormTextarea: React.FC<{label: string, name: string, placeholder?: string, value: string, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void}> = 
    ({label, name, placeholder = '', value, onChange}) => (
    <div>
        <label htmlFor={name} className="block mb-2 text-sm font-medium text-gray-300">{label}</label>
        <textarea id={name} name={name} rows={4} value={value} onChange={onChange} className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 resize-none" placeholder={placeholder}></textarea>
    </div>
);

const ServiceForm: React.FC<ServiceFormProps> = ({ serviceType, title, onBack, onSubmit }) => {
    const [formData, setFormData] = useState<{ [key: string]: string }>({});
    const [locationLoading, setLocationLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleGetLocation = () => {
        if (navigator.geolocation) {
            setLocationLoading(true);
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    setFormData(prev => ({
                        ...prev,
                        from: `Lat: ${latitude.toFixed(5)}, Lon: ${longitude.toFixed(5)}`
                    }));
                    setLocationLoading(false);
                },
                (error) => {
                    console.error("Error getting location", error);
                    alert("تعذر الحصول على الموقع. يرجى التأكد من تمكين خدمات الموقع والموافقة على الإذن.");
                    setLocationLoading(false);
                }
            );
        } else {
            alert("المتصفح لا يدعم تحديد الموقع الجغرافي.");
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    const renderFormFields = () => {
        switch (serviceType) {
            case 'transport':
                return (
                    <>
                        <FormInput label="الاسم بالكامل" name="fullName" placeholder="اسم طالب الخدمة" value={formData.fullName || ''} onChange={handleChange} />
                        <FormInput label="رقم الهاتف" name="phone" type="tel" placeholder="01xxxxxxxxx" value={formData.phone || ''} onChange={handleChange} />
                        
                        <div>
                            <label htmlFor="from" className="block mb-2 text-sm font-medium text-gray-300">نقطة الانطلاق</label>
                            <div className="relative">
                                <input 
                                    type="text" 
                                    id="from" 
                                    name="from" 
                                    value={formData.from || ''} 
                                    onChange={handleChange} 
                                    className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5 pr-12"
                                    placeholder="مثال: ميدان التحرير، أو استخدم موقعك الحالي" 
                                    required 
                                />
                                <button 
                                    type="button" 
                                    onClick={handleGetLocation} 
                                    disabled={locationLoading}
                                    className="absolute top-1/2 right-1 -translate-y-1/2 p-2 text-gray-400 hover:text-purple-400 transition-colors disabled:text-gray-500 disabled:cursor-wait"
                                    aria-label="استخدام الموقع الحالي"
                                >
                                    {locationLoading ? (
                                        <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                    ) : (
                                        <LocationMarkerIcon className="w-6 h-6" />
                                    )}
                                </button>
                            </div>
                        </div>

                        <FormInput label="الوجهة" name="to" placeholder="مثال: سيتي ستارز، مدينة نصر" value={formData.to || ''} onChange={handleChange} />

                        <FormSelect label="نوع المركبة المطلوبة" name="vehicleType" value={formData.vehicleType || ''} onChange={handleChange}>
                            <option value="">اختر نوع المركبة...</option>
                            <option value="سيارة ملاكي">سيارة ملاكي (للفرد أو العائلة)</option>
                            <option value="ميكروباص">ميكروباص (للمجموعات المتوسطة)</option>
                            <option value="باص">باص (للمجموعات الكبيرة)</option>
                            <option value="شاحنة ربع نقل">شاحنة ربع نقل</option>
                            <option value="شاحنة نصف نقل">شاحنة نصف نقل</option>
                            <option value="شاحنة نقل">شاحنة نقل (كبيرة)</option>
                        </FormSelect>

                        <FormInput label="تاريخ الرحلة" name="date" type="date" value={formData.date || ''} onChange={handleChange} />
                        <FormInput label="وقت الرحلة" name="time" type="time" value={formData.time || ''} onChange={handleChange} />
                        <FormInput label="عدد الركاب" name="passengers" type="number" placeholder="1" value={formData.passengers || ''} onChange={handleChange} />
                        <FormTextarea label="ملاحظات إضافية" name="notes" placeholder="هل يوجد حقائب؟ هل تحتاج لمقعد أطفال؟" value={formData.notes || ''} onChange={handleChange} />
                    </>
                );
            case 'craftsmen':
                return (
                    <>
                        <FormSelect label="نوع الحرفة المطلوبة" name="craft" value={formData.craft || ''} onChange={handleChange}>
                            <option value="">اختر الحرفة...</option>
                            <option value="سباك">سباك</option>
                            <option value="كهربائي">كهربائي</option>
                            <option value="نجار">نجار</option>
                            <option value="فني تكييف">فني تكييف وتبريد</option>
                            <option value="نقاش">نقاش (دهانات)</option>
                            <option value="أخرى">أخرى (يرجى التوضيح في الوصف)</option>
                        </FormSelect>
                        <FormTextarea label="وصف دقيق للمهمة المطلوبة" name="description" placeholder="مثال: تركيب 3 وحدات إضاءة جديدة في السقف، دهان جدران غرفة النوم باللون الأبيض..." value={formData.description || ''} onChange={handleChange} />
                        <FormInput label="المدة المتوقعة للعمل (بالأيام)" name="duration" type="number" placeholder="1" value={formData.duration || ''} onChange={handleChange} />
                        <FormInput label="العنوان بالكامل" name="address" placeholder="المدينة، الحي، الشارع، رقم المبنى" value={formData.address || ''} onChange={handleChange} />
                        <FormInput label="الوقت والتاريخ المفضل للحضور" name="datetime" type="datetime-local" value={formData.datetime || ''} onChange={handleChange} />
                    </>
                );
            case 'appointments':
                return (
                    <>
                        <FormSelect label="نوع الموعد" name="appointmentType" value={formData.appointmentType || ''} onChange={handleChange}>
                            <option value="">اختر الخدمة...</option>
                            <option value="محاماة">استشارة قانونية / محاماة</option>
                            <option value="كوافير">حجز كوافير / صالون تجميل</option>
                            <option value="عيادة أسنان">كشف / متابعة عيادة أسنان</option>
                            <option value="مراجعة طبيب">مراجعة طبيب (تخصص عام)</option>
                            <option value="دروس خصوصية">سنتر ودروس خصوصية</option>
                            <option value="أخرى">أخرى</option>
                        </FormSelect>
                        <FormInput label="الاسم بالكامل" name="fullName" placeholder="اسم طالب الخدمة" value={formData.fullName || ''} onChange={handleChange} />
                        <FormInput label="رقم الهاتف للتواصل" name="phone" type="tel" placeholder="01xxxxxxxxx" value={formData.phone || ''} onChange={handleChange} />
                        <FormInput label="التاريخ والوقت المفضل للموعد" name="datetime" type="datetime-local" value={formData.datetime || ''} onChange={handleChange} />
                        <FormTextarea label="سبب الحجز / ملاحظات" name="reason" placeholder="اذكر سبب الحجز أو أي تفاصيل هامة." value={formData.reason || ''} onChange={handleChange} />
                    </>
                );
            case 'home_services':
                 return (
                    <>
                        <FormSelect label="نوع الخدمة المنزلية" name="homeServiceType" value={formData.homeServiceType || ''} onChange={handleChange}>
                            <option value="">اختر الخدمة...</option>
                            <option value="توصيل للمنزل">طلب توصيل للمنزل (دليفري)</option>
                            <option value="تنظيف منازل">خدمات تنظيف منازل</option>
                            <option value="مكافحة حشرات">خدمات مكافحة حشرات ورش مبيدات</option>
                            <option value="نقل أثاث">خدمات نقل أثاث</option>
                            <option value="أخرى">أخرى (يرجى التوضيح)</option>
                        </FormSelect>
                         <FormInput label="العنوان بالتفصيل" name="address" placeholder="المدينة، الحي، الشارع، رقم المبنى" value={formData.address || ''} onChange={handleChange} />
                         <FormTextarea label="وصف الطلب" name="description" placeholder="مثال: توصيل طلبات من السوبر ماركت، تنظيف شقة 3 غرف..." value={formData.description || ''} onChange={handleChange} />
                         <FormInput label="الوقت والتاريخ المطلوب" name="datetime" type="datetime-local" value={formData.datetime || ''} onChange={handleChange} />
                    </>
                );
            default:
                return <p>حدث خطأ، يرجى العودة للخلف.</p>;
        }
    };

    return (
        <div className="bg-gray-800 rounded-2xl p-6 md:p-8 border border-gray-700 shadow-2xl w-full animate-fade-in">
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">{title}</h2>
                <button onClick={onBack} className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-gray-700">
                    <ArrowRightIcon className="w-6 h-6 rtl-flip" />
                    <span className="sr-only">عودة</span>
                </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                {renderFormFields()}
                <button type="submit" className="w-full flex items-center justify-center gap-3 bg-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-purple-700 active:bg-purple-800 transition-all duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed transform hover:scale-105 disabled:scale-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500">
                    إرسال الطلب
                </button>
            </form>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default ServiceForm;