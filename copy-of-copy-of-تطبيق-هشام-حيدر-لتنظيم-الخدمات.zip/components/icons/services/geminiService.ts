import React from 'react';

interface ServiceCardProps {
    title: string;
    description: string;
    icon: React.ReactNode;
    onClick: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, onClick }) => {
    return React.createElement('button', {
            onClick: onClick,
            className: "group w-full bg-gray-800 hover:bg-gray-700/80 border border-gray-700 rounded-2xl p-6 text-right transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl hover:shadow-purple-500/10"
        },
        React.createElement('div', { className: "flex items-center gap-5" },
            React.createElement('div', { className: "bg-gray-900 p-4 rounded-xl border border-gray-600 group-hover:bg-purple-600 group-hover:border-purple-500 transition-colors duration-300" },
                icon
            ),
            React.createElement('div', { className: "flex-1" },
                React.createElement('h3', { className: "text-xl font-bold text-white group-hover:text-purple-300 transition-colors duration-300" }, title),
                React.createElement('p', { className: "text-gray-400 mt-1 text-sm" }, description)
            )
        )
    );
};

export default ServiceCard;
