
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Scene } from '../../types.ts';
import { PlayIcon } from './PlayIcon.tsx';
import { PauseIcon } from './PauseIcon.tsx';
import { RewindIcon } from './RewindIcon.tsx';
import { DownloadIcon } from './DownloadIcon.tsx';
import { VolumeUpIcon } from './VolumeUpIcon.tsx';
import { VolumeOffIcon } from './VolumeOffIcon.tsx';


interface VideoPlayerProps {
  scenes: Scene[];
}

const SCENE_DURATION_MS = 5000;

const kenBurnsAnimations = [
  'ken-burns-zoom-in', 'ken-burns-zoom-out', 'ken-burns-pan-tr', 'ken-burns-pan-bl',
];

const VideoPlayer: React.FC<VideoPlayerProps> = ({ scenes }) => {
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  const sceneAnimations = useMemo(() => 
    scenes.map(() => kenBurnsAnimations[Math.floor(Math.random() * kenBurnsAnimations.length)]),
  [scenes]);

  // Load available voices
  useEffect(() => {
    const handleVoicesChanged = () => {
        setVoices(window.speechSynthesis.getVoices());
    };
    // Voices load asynchronously. We need to listen for the event.
    window.speechSynthesis.addEventListener('voiceschanged', handleVoicesChanged);
    handleVoicesChanged(); // For browsers that load them immediately
    return () => {
        window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
    };
  }, []);


  const currentScene = scenes[currentSceneIndex];

  const speak = useCallback((scene: Scene) => {
    if (isMuted || typeof window === 'undefined' || !window.speechSynthesis || !scene) return;
    
    window.speechSynthesis.cancel();
    
    const { narration, dialect, voiceProfile } = scene;
    const utterance = new SpeechSynthesisUtterance(narration);
    
    const findBestVoice = (): SpeechSynthesisVoice | null => {
        if (!voices || voices.length === 0) return null;

        const langPreferences = (dialect === 'Egyptian' || dialect === 'Saidi') 
            ? ['ar-EG', 'ar-'] 
            : ['ar-SA', 'ar-'];

        const profileKeywords = {
            'Male': ['male', 'man', 'رجل'],
            'Female': ['female', 'woman', 'امرأة', 'فتاة'],
            'Child': ['child', 'boy', 'girl', 'طفل', 'طفلة'],
        };

        const checkProfile = (voiceName: string, profile: Scene['voiceProfile']): boolean => {
            if (!profile || profile === 'Neutral' || !profileKeywords[profile]) return true; // Neutral matches any
            const lowerCaseName = voiceName.toLowerCase();
            return profileKeywords[profile].some(keyword => lowerCaseName.includes(keyword));
        };
        
        // 1. Try for perfect match: specific dialect + specific profile
        for (const lang of langPreferences) {
            const matchingVoices = voices.filter(v => v.lang.startsWith(lang) && checkProfile(v.name, voiceProfile));
            if (matchingVoices.length > 0) return matchingVoices[0];
        }

        // 2. Fallback: Any Arabic voice with specific profile
        const profileVoices = voices.filter(v => v.lang.startsWith('ar-') && checkProfile(v.name, voiceProfile));
        if (profileVoices.length > 0) return profileVoices[0];

        // 3. Fallback: Specific dialect with any profile
         for (const lang of langPreferences) {
            const dialectVoices = voices.filter(v => v.lang.startsWith(lang));
            if (dialectVoices.length > 0) return dialectVoices[0];
        }
        
        // 4. Fallback: Any Arabic voice
        const anyArabicVoice = voices.find(v => v.lang.startsWith('ar-'));
        if (anyArabicVoice) return anyArabicVoice;

        return null; // No suitable voice found
    };
    
    const selectedVoice = findBestVoice();
    
    if (selectedVoice) {
        utterance.voice = selectedVoice;
        utterance.lang = selectedVoice.lang; // Important to set lang for consistency
    } else {
        utterance.lang = 'ar-SA'; // Fallback language if no voice found
    }

    window.speechSynthesis.speak(utterance);
  }, [isMuted, voices]);

  const goToNextScene = useCallback(() => {
    const nextIndex = (currentSceneIndex + 1) % scenes.length;
    setCurrentSceneIndex(nextIndex);
    speak(scenes[nextIndex]);
  }, [currentSceneIndex, scenes, speak]);

  useEffect(() => {
    speak(currentScene);
    if (isPlaying) {
      const timer = setTimeout(goToNextScene, SCENE_DURATION_MS);
      return () => {
        clearTimeout(timer);
        window.speechSynthesis.cancel();
      };
    }
  }, [currentSceneIndex, isPlaying, goToNextScene, currentScene, speak]);
  
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    if (isPlaying) {
      window.speechSynthesis.pause();
    } else {
      window.speechSynthesis.resume();
    }
  };
  
  const handleRestart = () => {
    setCurrentSceneIndex(0);
    setIsPlaying(true);
    window.speechSynthesis.cancel();
    speak(scenes[0]);
  };

  const handleToggleMute = () => {
    const newMutedState = !isMuted;
    setIsMuted(newMutedState);
    if (newMutedState) {
      window.speechSynthesis.cancel();
    } else {
      // Speak the current narration again when unmuting
      speak(currentScene);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });

      mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: 'video/webm' });
      recordedChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'video-ai.webm';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        setIsRecording(false);
      };

      stream.getVideoTracks()[0].onended = () => {
        stopRecording();
      };
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error starting recording:", err);
      alert("فشل بدء التسجيل. يرجى التأكد من منح الإذن اللازم.");
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
  };

  if (!scenes || scenes.length === 0) return null;

  return (
    <div className="w-full h-full flex flex-col bg-black">
      <div className="relative flex-grow w-full overflow-hidden group">
        {scenes.map((scene, index) => (
            <div key={index} className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSceneIndex ? 'opacity-100' : 'opacity-0'}`}>
                {scene.imageUrl && (
                    <img src={scene.imageUrl} alt={scene.sceneDescription} className="w-full h-full object-cover"
                        style={{
                            animationName: index === currentSceneIndex ? sceneAnimations[index] : 'none',
                            animationDuration: `${SCENE_DURATION_MS}ms`,
                            animationTimingFunction: 'linear', animationFillMode: 'forwards',
                            animationPlayState: isPlaying ? 'running' : 'paused',
                        }}/>
                )}
            </div>
        ))}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent p-6">
          <p className="text-lg md:text-2xl font-bold text-white text-center drop-shadow-lg animate-fade-in">{currentScene.narration}</p>
        </div>
        {isRecording && <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full flex items-center gap-2 text-sm animate-pulse"><div className="w-3 h-3 bg-white rounded-full"></div>جاري التسجيل...</div>}
      </div>
      
      <div className="flex-shrink-0 bg-gray-900/80 backdrop-blur-sm p-4">
        <div className="w-full bg-gray-700 rounded-full h-1.5 mb-4 overflow-hidden">
             <div key={currentSceneIndex} className="bg-purple-500 h-1.5 rounded-full"
                  style={{ animation: isPlaying ? `progress ${SCENE_DURATION_MS}ms linear` : 'none', width: isPlaying ? undefined : '0%'}}/>
        </div>
        <div className="flex items-center justify-center gap-4 sm:gap-6">
            <button onClick={handleRestart} className="text-gray-300 hover:text-white transition-colors" title="إعادة"><RewindIcon className="w-7 h-7" /></button>
            <button onClick={handlePlayPause} className="text-white bg-purple-600 rounded-full p-3 hover:bg-purple-700 transition-colors" title={isPlaying ? "إيقاف مؤقت" : "تشغيل"}>
                {isPlaying ? <PauseIcon className="w-8 h-8"/> : <PlayIcon className="w-8 h-8"/>}
            </button>
            <button onClick={handleToggleMute} className="text-gray-300 hover:text-white transition-colors" title={isMuted ? "تشغيل الصوت" : "كتم الصوت"}>
                {isMuted ? <VolumeOffIcon className="w-7 h-7" /> : <VolumeUpIcon className="w-7 h-7" />}
            </button>
            <button onClick={isRecording ? stopRecording : startRecording} className={`text-gray-300 hover:text-white transition-colors ${isRecording ? 'text-red-500 hover:text-red-400' : ''}`} title={isRecording ? "إيقاف التسجيل" : "تحميل الفيديو"}>
                <DownloadIcon className="w-7 h-7" />
            </button>
             <div className="text-gray-300 font-mono text-sm w-16 text-center">{currentSceneIndex + 1} / {scenes.length}</div>
        </div>
      </div>
      <style>{`
        @keyframes progress { from { width: 0%; } to { width: 100%; } }
        @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fade-in 0.5s ease-out; }
        @keyframes ken-burns-zoom-in { 0% { transform: scale(1.0) translateY(0); } 100% { transform: scale(1.15) translateY(2%); } }
        @keyframes ken-burns-zoom-out { 0% { transform: scale(1.15) translateY(2%); } 100% { transform: scale(1.0) translateY(0); } }
        @keyframes ken-burns-pan-tr { 0% { transform: scale(1.2) translate(-5%, 5%); } 100% { transform: scale(1.2) translate(0, 0); } }
        @keyframes ken-burns-pan-bl { 0% { transform: scale(1.2) translate(5%, -5%); } 100% { transform: scale(1.2) translate(0, 0); } }
        [style*="animation-name: ken-burns-zoom-in"] { animation-name: ken-burns-zoom-in; }
        [style*="animation-name: ken-burns-zoom-out"] { animation-name: ken-burns-zoom-out; }
        [style*="animation-name: ken-burns-pan-tr"] { animation-name: ken-burns-pan-tr; }
        [style*="animation-name: ken-burns-pan-bl"] { animation-name: ken-burns-pan-bl; }
      `}</style>
    </div>
  );
};

export default VideoPlayer;