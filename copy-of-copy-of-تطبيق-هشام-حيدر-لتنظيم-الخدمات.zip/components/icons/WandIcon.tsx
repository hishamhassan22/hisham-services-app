import React from 'react';

export const WrenchIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.658-.404 1.238-1.063.996-1.745-.496-3.49-1.221-5.234-2.191a22.35 22.35 0 01-4.132 0c-1.745.97-3.49 1.695-5.234 2.191-1.28.362-1.837-.338-1.063-.996l1.263-12a1.125 1.125 0 011.125-1h11.25a1.125 1.125 0 011.125 1z" />
  </svg>
);
