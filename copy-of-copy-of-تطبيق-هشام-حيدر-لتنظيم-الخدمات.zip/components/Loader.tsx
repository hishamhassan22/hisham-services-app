
import React from 'react';

interface ConfirmationScreenProps {
    onBackToHome: () => void;
    title: string;
    message: React.ReactNode;
}

const ConfirmationScreen: React.FC<ConfirmationScreenProps> = ({ onBackToHome, title, message }) => {
    return (
        <div className="bg-gray-800 rounded-2xl p-8 md:p-12 border border-gray-700 shadow-2xl w-full text-center animate-fade-in">
            <div className="w-20 h-20 bg-green-500/20 border-2 border-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
            </div>
            <h2 className="text-3xl font-bold text-white mb-3">{title}</h2>
            <div className="text-gray-300 mb-8 max-w-md mx-auto">
                {message}
            </div>
            <button
                onClick={onBackToHome}
                className="bg-purple-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-purple-700 active:bg-purple-800 transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500"
            >
                العودة إلى الرئيسية
            </button>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: scale(0.95); }
                    to { opacity: 1; transform: scale(1); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default ConfirmationScreen;
